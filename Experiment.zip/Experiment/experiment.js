var magnet;
var gal2;
var new_x;
var check;
var velocity;
var torus3;
var lampBulb;
var helpContent;
var infoContent;
var north;
var south;
var flip;
var Switch;
var arrow1a;
var arrow1b;
var arrow2a;
var arrow2b;
var arrow3a;
var arrow3b;
var arrow4a;
var arrow4b;


function initialiseHelp()
{
    helpContent="";
    helpContent = helpContent + "<h2>Electromagnetic induction in a coil help</h2>";
    helpContent = helpContent + "<h3>About the experiment</h3>";
    helpContent = helpContent + "<p>Shown how the deflection changes with velocity of the magnet and its distance from the coil.</p>";
    helpContent = helpContent + "<h3>Animation control</h3>";
    helpContent = helpContent + "<p>Drag the magnet to desired position.</p>";
    helpContent = helpContent + "<p>Flip the magnet if wished.</p>";
    helpContent = helpContent + "<p>Click on start button to start the animation</p>";
	helpContent = helpContent + "<p>Drag the magnet to see the deflection in the galvanometer.</p>";
    helpContent = helpContent + "<p>Click on pause button to pause the animation</p>";
    helpContent = helpContent + "<p>Click on Reset button to reset animation</p>";
    infoContent = infoContent + "<h2>Happy Experimenting</h2>";
    PIEupdateHelp(helpContent);
}

function initialiseInfo()
{
    infoContent =  "";
    infoContent = infoContent + "<h2>Electromagnetic induction in a coil concepts</h2>";
    infoContent = infoContent + "<h3>About the experiment</h3>";
    infoContent = infoContent + "<p>Shown how the deflection changes with change of flux associated with the coil.</p>";
    infoContent = infoContent + "<p>When the magnet is flipped, there is opposite deflection in the galvanometer.</p>";
    infoContent = infoContent + "<h3>Current Flow</h3>";
    infoContent = infoContent + "<p>According to the Faraday’s Law of Induction, a voltage is induced in a circuit whenever relative motion exists between a conductor and a magnetic field and that the magnitude of this voltage is proportional to the rate of change of the flux. </p>";
    infoContent = infoContent + "<p>According to Lenz’s Law, the direction of an induced emf is such that it will always opposes the change that is causing it.</p>";
    infoContent = infoContent + "<p>If the magnet is moved far from the coil, there is less change of magnetic flux associated with the coil, so the deflection observed in galvanometer is less.</p>";
	infoContent = infoContent + "<p>If the magnet is moved at more velocity, the rate of change of flux increase, so the deflection observed in galvanometer is more.</p>";
	infoContent = infoContent + "<p>If the magnet is flipped, the polarity changes due to which to counter the flux the current flows in opposite direction, so we get opposite deflection in the galvanometer.</p>";
    infoContent = infoContent + "<h2>Happy Experimenting</h2>";
    PIEupdateInfo(infoContent);
}

function addArrows()
{
	arrow1a = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.7),new THREE.MeshBasicMaterial({ color:"red"}));
	arrow1a.position.set(-3.81,-2,-10000);
	PIEaddElement(arrow1a);
	
	arrow1b=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow1b.position.set(-3.81,-2,-10000);
	PIEaddElement(arrow1b);
	
	arrow2a=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow2a.position.set(-2.45,0.7,-10000);
	PIEaddElement(arrow2a);	
	
	arrow2b=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow2b.position.set(-2.45,0.7,-10000);
	PIEaddElement(arrow2b);
	
	arrow3a=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow3a.position.set(1.5,0.7,-10000);
	PIEaddElement(arrow3a);
	
	arrow3b=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow3b.position.set(1.5,0.7,-10000);
	PIEaddElement(arrow3b);
	
	arrow4a=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow4a.position.set(5.25,-4.2,-10000);
	PIEaddElement(arrow4a);
	
	arrow4b=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow4b.position.set(5.25,-4.2,-10000);
	PIEaddElement(arrow4b);
	
}

function noarrows()
{
	arrow1a.position.set(-3.81,-2,-10000);
	arrow1b.position.set(-3.81,-2,-10000);
	arrow2a.position.set(-2.45,0.7,-10000);
	arrow2b.position.set(-2.45,0.7,-10000);
	arrow3a.position.set(1.5,0.7,-10000);
	arrow3b.position.set(1.5,0.7,-10000);
	arrow4a.position.set(5.25,-4.2,-10000);
	arrow4b.position.set(5.25,-4.2,-10000);	
}

function arrowpos_1()
{
	arrow1a.position.set(-4,-2,-1);
	arrow1a.rotation.z=Math.PI/6;
	
	arrow1b.position.set(-3.6,-2,-1);
	arrow1b.rotation.z=-Math.PI/6;
	
	arrow2a.position.set(-2.45,0.9,-1);
	arrow2a.rotation.z=-Math.PI/3;
	
	arrow2b.position.set(-2.45,0.5,-1);
	arrow2b.rotation.z=+Math.PI/3;
	
	arrow3a.position.set(1.5,0.5,-1);
	arrow3a.rotation.z=+Math.PI/3;
	
	arrow3b.position.set(1.5,0.9,-1);
	arrow3b.rotation.z=-Math.PI/3;
	
	arrow4a.position.set(5.48,-4.2,-1);
	arrow4a.rotation.z=+Math.PI/6;
	
	arrow4b.position.set(5.02,-4.2,-1);
	arrow4b.rotation.z=-Math.PI/6;
}

function arrowpos_2()
{
	arrow1a.position.set(-3.6,-2,-1);
	arrow1a.rotation.z=+Math.PI/6;
		
	arrow1b.position.set(-4.02,-2,-1);
	arrow1b.rotation.z=-Math.PI/6;
	
	arrow2a.position.set(-2.45,0.9,-1);
	arrow2a.rotation.z=+Math.PI/3;
	
	arrow2b.position.set(-2.45,0.5,-1);
	arrow2b.rotation.z=-Math.PI/3;
	
	arrow3a.position.set(1.5,0.5,-1);
	arrow3a.rotation.z=-Math.PI/3;
	
	arrow3b.position.set(1.5,0.9,-1);
	arrow3b.rotation.z=+Math.PI/3;
	
	arrow4a.position.set(5.48,-4.2,-1);
	arrow4a.rotation.z=-Math.PI/6;
	
	arrow4b.position.set(5.02,-4.2,-1);
	arrow4b.rotation.z=+Math.PI/6;
}

function addClipper()
{
	Switch = new THREE.Mesh(new THREE.BoxGeometry(1,0.1,0.1),new THREE.MeshBasicMaterial({color:"red"}));
	Switch.position.set(5.08,-1.77,1);
	Switch.rotation.z=Math.PI/3;
	PIEaddElement(Switch);
	
	var box = new THREE.Mesh(new THREE.TorusGeometry(0.83,0.07,100,100),new THREE.MeshPhongMaterial({color:"gray"}));
	box.position.set(4.63,-1.7,2);
	PIEaddElement(box);
	
}

function addMagnet()
{
	var geometry=new	THREE.BoxGeometry(4,1,1,16);
	var material=new THREE.MeshLambertMaterial({color:"red"});
	magnet=new THREE.Mesh(geometry,material);
	magnet.position.set(-6, -3.7, 1);
	
	var geo = new THREE.EdgesGeometry( geometry ); 
	var mat = new THREE.LineBasicMaterial( { color: "black", linewidth: 1} );
	var wireframe = new THREE.LineSegments( geo, mat );
	magnet.add(wireframe);
	
	var geometry2=new	THREE.BoxGeometry(2,1,1,16);
	var material2=new THREE.MeshLambertMaterial({color:"blue"});
	var mesh2=new THREE.Mesh(geometry2,material2);
	mesh2.position.set(1, 0, 0);
	
	var geo2 = new THREE.EdgesGeometry( geometry2 ); 
	var mat2 = new THREE.LineBasicMaterial( { color: "black", linewidth: 1 } );
	var wireframe2 = new THREE.LineSegments( geo2, mat2);
	mesh2.add(wireframe2);
	
	magnet.add(mesh2);
	
	north = new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,0.4,32),new THREE.MeshPhongMaterial({color:"white"}));
    north.geometry.translate(-1.7,0,1);
   

    var north2 = new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,0.4,32),new THREE.MeshPhongMaterial({color:"white"}));
    north2.position.set(-1.6,0,1);
    north2.rotation.z += Math.PI/6;
    north.add(north2);

    var north3 = new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,0.4,32),new THREE.MeshPhongMaterial({color:"white"}));
    north3.geometry.translate(-1.5,0,1);
    north.add(north3);
	magnet.add(north);
	
	south = new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,0.15,32),new THREE.MeshPhongMaterial({color:"white"}));
    south.geometry.translate(1.4,0.1,1);

    var south2 = new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,0.2,32),new THREE.MeshPhongMaterial({color:"white"}))
    south2.position.set(1.5,0.2,1);
    south2.rotation.z += Math.PI/2;
    south.add(south2);

    var south3 = new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,0.2,32),new THREE.MeshPhongMaterial({color:"white"}));
  south3.position.set(1.5,0,1);
	south3.rotation.z += Math.PI/2;
    south.add(south3);
	
	var south4 = new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,0.15,32),new THREE.MeshPhongMaterial({color:"white"}));
    south4.position.set(1.6,-0.11,1);
    south.add(south4);
	
	var south5 = new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,0.2,32),new THREE.MeshPhongMaterial({color:"white"}));
   south5.position.set(1.49,-0.19,1);
	south5.rotation.z += Math.PI/2;
    south.add(south5);
	
	magnet.add(south);

	PIEaddElement(magnet);
	
}

function mydragmagnet(element,newpos)
{
	var newx;
	
	if(newpos.x>=8)
		newx=8;
	else if(newpos.x<=-8)
		newx=-8;
	else
		newx=newpos.x;
	magnet.position.set(newx,-3.7,1);
	PIErender();
}

function addCoil()
{
	var geometry = new THREE.TorusGeometry( 1.2, 0.1, 16, 100 );
	var material = new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } );
	var torus = new THREE.Mesh( geometry, material );
	torus.position.set(-1.9,-3.5,1);
	torus.rotation.y+=Math.PI/2.3;
	PIEaddElement(torus);
	
	var geometry2 = new THREE.TorusGeometry( 1.2, 0.1, 16, 100 );
	var material2 = new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } );
	var torus2 = new THREE.Mesh( geometry2, material2 );
	torus2.position.set(-1.5,-3.5,1);
	torus2.rotation.y+=Math.PI/2.3;
	PIEaddElement(torus2);


	var geometry3 = new THREE.TorusGeometry( 1.2, 0.1, 16, 100 );
	var material3 = new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } );
	torus3 = new THREE.Mesh( geometry3, material3 );
	torus3.position.set(-1.1,-3.5,1);
	torus3.rotation.y+=Math.PI/2.3;
	PIEaddElement(torus3);
	
	var geometry4 = new THREE.TorusGeometry( 1.2, 0.1, 16, 100 );
	var material4 = new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } );
	var torus4 = new THREE.Mesh( geometry4, material4 );
	torus4.position.set(-0.7,-3.5,1);
	torus4.rotation.y+=Math.PI/2.3;
	PIEaddElement(torus4);
	
	var geometry5 = new THREE.TorusGeometry( 1.2, 0.1, 16, 100 );
	var material5 = new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } );
	var torus5 = new THREE.Mesh( geometry5, material5 );
	torus5.position.set(-0.3,-3.5,1);
	torus5.rotation.y+=Math.PI/2.3;
	PIEaddElement(torus5);
	
	var geometry6 = new THREE.TorusGeometry( 1.2, 0.1, 16, 100 );
	var material6 = new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40} );
	var torus6 = new THREE.Mesh( geometry5, material5 );
	torus6.position.set(0.1,-3.5,1);
	torus6.rotation.y+=Math.PI/2.3;
	PIEaddElement(torus6);

	var geometry7 = new THREE.TorusGeometry( 1.2, 0.1, 16, 100 );
	var material7 = new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } );
	var torus7 = new THREE.Mesh( geometry5, material5 );
	torus7.position.set(0.5,-3.5,1);
	torus7.rotation.y+=Math.PI/2.3;
	PIEaddElement(torus7);
	
	var geometry8 = new THREE.TorusGeometry( 1.2, 0.1, 16, 100 );
	var material8 = new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } );
	var torus8 = new THREE.Mesh( geometry5, material5 );
	torus8.position.set(0.9,-3.5,1);
	torus8.rotation.y+=Math.PI/2.3;
	PIEaddElement(torus8);
	
	var geometry9 = new THREE.TorusGeometry( 1.2, 0.1, 16, 100 );
	var material9 = new THREE.MeshPhongMaterial( { color:0xa4672d,sharpness:40 } );
	var torus9 = new THREE.Mesh( geometry5, material5 );
	torus9.position.set(1.3,-3.5,1);
	torus9.rotation.y+=Math.PI/2.3;
	PIEaddElement(torus9);
	
}

function addMeter()
{
	var g1=new THREE.CylinderGeometry(1.5,1.5,0.6,100);
	var m1=new THREE.MeshPhongMaterial({color:"gray"});
	var gal = new THREE.Mesh(g1,m1);
	gal.rotation.x=+Math.PI/5.5;
	gal.position.set(-0.5,2.3,0);
	
	var geo1 = new THREE.EdgesGeometry( g1 ); 
	var mat1 = new THREE.LineBasicMaterial( { color: "black", linewidth: 1} );
	var wireframe1 = new THREE.LineSegments( geo1, mat1 );
	gal.add(wireframe1);
	
	
	
	var g2=new THREE.BoxGeometry(2.3,0.07,0.07);
	var m2=new THREE.MeshPhongMaterial({color:"black"});
	gal2=new THREE.Mesh(g2,m2);
	gal2.position.set(-0.5,2.45,0.6);
	gal2.rotation.x=+Math.PI/5.5;
	gal2.rotation.y+=Math.PI/2+Math.PI/50;
	
	var geo2 = new THREE.EdgesGeometry( g2 );
	var mat2 = new THREE.LineBasicMaterial( { color: "white", linewidth: 1} );
	var wireframe2 = new THREE.LineSegments( geo2, mat2 );
	gal2.add(wireframe2);
	PIEaddElement(gal2);
	
	var x1=new THREE.Mesh(new THREE.BoxGeometry(0.4,0.05,0.05),new THREE.MeshBasicMaterial({color:"white"}));
	x1.position.set(-1.5,2.4,0.65);
	PIEaddElement(x1);
	
	var x2=new THREE.Mesh(new THREE.BoxGeometry(0.25,0.05,0.05),new THREE.MeshBasicMaterial({color:"white"}));
	x2.position.set(-1.5,2.4,0.65);
	x2.rotation.z+=Math.PI*0.5;
	x2.rotation.x+=+Math.PI/5.5;
	PIEaddElement(x2);
	
	var x3=new THREE.Mesh(new THREE.BoxGeometry(0.4,0.05,0.05),new THREE.MeshBasicMaterial({color:"white"}));
	x3.position.set(0.5,2.4,0.65);
	PIEaddElement(x3);
	
	PIEaddElement(gal);
}

function addWires()
{
	 var lw1=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshPhongMaterial({ color:0xa4672d,sharpness:40 }));
	 lw1.position.set(1.35,-5.4,-1);
	PIEaddElement(lw1);
	
	 var lw2=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,1.65),new THREE.MeshPhongMaterial({ color:0xa4672d,sharpness:40 }));
	 lw2.position.set(-1.8,-5,-1);
	PIEaddElement(lw2);
	
	 var lw3=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,4),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw3.position.set(3.3,-5.8,-1);
	 lw3.rotation.z+=Math.PI*0.5;
	PIEaddElement(lw3);
	
	 var lw4=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,2),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw4.position.set(-2.85,-5.8,-1);
	 lw4.rotation.z+=Math.PI*0.5;
	PIEaddElement(lw4);
	
	 var lw5a=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,3.5),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw5a.position.set(5.25,-4.1,-1);
	PIEaddElement(lw5a);
	
	var lw5b=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,2.1),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw5b.position.set(5.25,-0.3,-1);
	PIEaddElement(lw5b);
	
	var lw6=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,6.5),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw6.position.set(-3.81,-2.5,-1);
	PIEaddElement(lw6);
	
	var lw7=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,5),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw7.position.set(2.8,0.7,-1);
	 lw7.rotation.z+=Math.PI*0.5;
	PIEaddElement(lw7);
	
	var lw8=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,2.8),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw8.position.set(-2.45,0.7,-1);
	 lw8.rotation.z+=Math.PI*0.5;
	PIEaddElement(lw8);
	
	var lw9=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,1),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw9.position.set(0.3,1.15,-1);
	PIEaddElement(lw9);
	
	 var lw10=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,1),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw10.position.set(-1,1.15,-1);
	PIEaddElement(lw10);
	
	
}

function addBulb()
{
    var lampBottomGeom = new THREE.CylinderGeometry(0.2, 0.2, 0.3, 12);
    var lampBottom = new THREE.Mesh(lampBottomGeom, new THREE.MeshPhongMaterial({color: "gray", shininess: 0}));
    lampBottom.position.set(3.3, 1, -1);
	lampBottom.rotation.x=+Math.PI/8;
    PIEaddElement(lampBottom);

    var lampBulbGeom = new THREE.SphereGeometry(0.7, 32, 24);
    lampBulbGeom.translate(0, 0.8, 0);
    lampBulb = new THREE.Mesh(lampBulbGeom, new THREE.MeshPhongMaterial({color: 0xffffff, transparent: true, opacity:0.8}));
    lampBottom.add(lampBulb);

    var baseGeom = new THREE.BoxGeometry( 1.5, 0.7,0.7  );
    baseGeom.translate(0,-0.4,0);
    var base = new THREE.Mesh(baseGeom, new THREE.MeshPhongMaterial( {color:"gray"} ));

    var edges = new THREE.EdgesGeometry( baseGeom );
    var line = new THREE.LineSegments( edges, new THREE.LineBasicMaterial( { color: 0x000 } ) );
    
    lampBottom.add( line );
    lampBottom.add(base);
	
}

function switch_on()
{
	Switch.rotation.z=Math.PI/2;
	Switch.position.set(4.85,-1.77,1);
}

function magnetflip()
{	
	if(flip==0)
	flip=1;
	else		
	flip=0;
	magnet.rotation.z+=Math.PI;
	PIErender();
}

function addElementsToScene()
{
	addCoil();
	addMeter();
	addBulb();
	addWires();
	addMagnet();
	addClipper();
	addArrows();
}

function initialisescene()
{
	PIEscene.background = new THREE.Color( 0x287A4C );
	
	var light =new THREE.PointLight( 0xffff66 ,0.7,100);
	light.position.set(0,0,50);
	PIEaddElement(light);
	
	check=0;
	velocity=0;
	new_x=200;
	flip=0;
}

function loadExperimentElements()
{

	initialiseHelp();
	initialiseInfo();
	initialisescene();
	addElementsToScene();
	
	PIEsetExperimentTitle("Electromagnetic induction in a coil");
    PIEsetDeveloperName("Aryaman");
	PIEsetAreaOfInterest(-11, 5,12,- 7);
	PIEaddInputCheckbox("Flip Magnet", false, magnetflip);
	
	PIEdragElement(magnet);
    PIEsetDrag(magnet,mydragmagnet);

}

function PIEstopAnimation()
{
	if(PIEanimationON==true){PIEpauseOffset=0;PIEcurrentTime=0;PIEoffsetTime=0;PIEanimationON=false;PIEanimationPaused=false;PIEresumeButton.style.display="none";PIEresumeButton.style.visibility="hidden";PIEpauseButton.style.display="inline";PIEpauseButton.style.visibility="hidden";PIEstopButton.style.display="none";PIEstartButton.style.display="inline";PIEshowInputPanel()}
	Switch.position.set(5.08,-1.77,1);
	Switch.rotation.z=Math.PI/3;
	noarrows();
	PIErender();
}

function resetExperiment()
{
	magnet.position.set(-6, -3.7, 1);
	if(flip==1)
	{
		magnet.rotation.z-=Math.PI;
		flip=0;
	}
	check=0;
	Switch.position.set(5.08,-1.77,1);
	Switch.rotation.z=Math.PI/3;
	noarrows();
	PIEchangeInputCheckbox("Flip Magnet", false)
}

function updateExperimentElements(t, dt) 
{  
var calc2;

if(new_x!=200)
{
	velocity=(magnet.position.x-new_x)/dt;
	switch_on();
}

new_x=magnet.position.x;

if(flip==0)
check=torus3.position.x-magnet.position.x;

if(flip==1)
check=-torus3.position.x+magnet.position.x;

if(check>-0.3 && check<=0)
	check=-0.3;
if(check<0.3&& check >0)
	check=0.3;

var calc = (10*velocity/check);

if(calc>0.350)
	calc=0.350;

if(calc<-0.350)
	calc=-0.350;

if(calc<0)
{
	calc2=-calc;
	arrowpos_2();
}
else if(calc>0)
{
	calc2=calc;
	arrowpos_1();
}

if(calc==0)
{
	lampBulb.material.color.set(0xFFFFFF);
	noarrows();
}
if(calc2<0.05 && calc2>0)
	lampBulb.material.color.set(0xFFFF66);
if(calc2>0.05)
	lampBulb.material.color.set(0xFFFF00);


gal2.rotation.y=Math.PI/2+Math.PI/50+calc*Math.PI;

}